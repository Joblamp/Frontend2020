# Procesverslag
**Auteur:** -Job Lamp-

Markdown cheat cheet: [Hulp bij het schrijven van Markdown](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet). Nb. de standaardstructuur en de spartaanse opmaak zijn helemaal prima. Het gaat om de inhoud van je procesverslag. Besteedt de tijd voor pracht en praal aan je website.



## Bronnenlijst
1. -bron 1-
2. -bron 2-
3. -...-



## Eindgesprek (week 7/8)

-dit ging goed & dit was lastig-

**Screenshot(s):**

-screenshot(s) van je eindresultaat-



## Voortgang 3 (week 6)

-same as voortgang 1-



## Voortgang 2 (week 5)

-same as voortgang 1-



## Voortgang 1 (week 3)

### Stand van zaken

-dit ging goed & dit was lastig-

**Screenshot(s):**

-screenshot(s) van hoe ver je bent-

### Agenda voor meeting

-samen met je groepje opstellen-

### Verslag van meeting

-na afloop snel uitkomsten vastleggen-



## Intake (week 1)

**Je startniveau:** Blauw

**Je focus:** Responsive

**Je opdracht:** https://nos.nl/

**Screenshot(s):** (images/NOSmobile.png) (images/NOStablet.png) (images/NOSweb.png)

![screenshot(s) die een goed beeld geven van de website die je gaat maken](images/NOSmobile.png)
![screenshot(s) die een goed beeld geven van de website die je gaat maken](images/NOStablet.png)
![screenshot(s) die een goed beeld geven van de website die je gaat maken](images/NOSweb.png)


**Breakdown-schets(en):** (images/NOS-breakdown1.jpg) (images/NOS-breakdown2.jpg) (images/NOS-breakdown3.jpg)

![-voorlopige breakdownschets(en) van een of beide pagina's van de site die je gaat maken-](images/NOS-breakdown1.jpg)
![-voorlopige breakdownschets(en) van een of beide pagina's van de site die je gaat maken-](images/NOS-breakdown2.jpg)
![-voorlopige breakdownschets(en) van een of beide pagina's van de site die je gaat maken-](images/NOS-breakdown3.jpg)
